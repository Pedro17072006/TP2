package com.example.paisesapi.service;

import com.example.paisesapi.model.ClimaDados;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.net.URL;

@Service
public class ClimaService {

    public ClimaDados buscarClima(double latitude, double longitude) {
        try {
            String urlStr = String.format(
                    "https://api.open-meteo.com/v1/forecast?latitude=%f&longitude=%f&current=temperature_2m,windspeed_10m,weathercode&timezone=America/Sao_Paulo",
                    latitude, longitude
            );

            URL url = new URL(urlStr);
            InputStream is = url.openStream();

            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(is, ClimaDados.class);

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public String traduzirWeatherCode(int code) {
        if (code == 0) return "Céu limpo";
        if (code >= 1 && code <= 3) return "Parcialmente nublado";
        if (code >= 45 && code <= 48) return "Neblina";
        if (code >= 61 && code <= 67) return "Chuva";
        if (code >= 71 && code <= 77) return "Neve";
        if (code >= 80 && code <= 82) return "Pancadas de chuva";

        return "Desconhecido";
    }
}