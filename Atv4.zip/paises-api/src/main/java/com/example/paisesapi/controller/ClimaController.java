package com.example.paisesapi.controller;

import com.example.paisesapi.model.ClimaDados;
import com.example.paisesapi.service.ClimaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ClimaController {

    @Autowired
    private ClimaService climaService;

    @GetMapping("/clima")
    public String mostrarFormulario() {
        return "clima";
    }

    @PostMapping("/clima")
    public String buscarClima(@RequestParam double latitude,
                              @RequestParam double longitude,
                              Model model) {

        ClimaDados dados = climaService.buscarClima(latitude, longitude);

        if (dados != null) {
            String descricao = climaService.traduzirWeatherCode(
                    dados.getClimaAtual().getWeathercode()
            );

            model.addAttribute("clima", dados);
            model.addAttribute("descricao", descricao);
        }

        return "resultadoClima";
    }
}