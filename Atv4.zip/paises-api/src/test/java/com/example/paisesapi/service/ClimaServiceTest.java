package com.example.paisesapi.service;

import com.example.paisesapi.service.ClimaService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ClimaServiceTest {

    private ClimaService climaService = new ClimaService();

    @Test
    void deveTraduzirWeatherCodeCorretamente() {
        assertEquals("Céu limpo", climaService.traduzirWeatherCode(0));
        assertEquals("Parcialmente nublado", climaService.traduzirWeatherCode(2));
        assertEquals("Chuva", climaService.traduzirWeatherCode(63));
    }
}