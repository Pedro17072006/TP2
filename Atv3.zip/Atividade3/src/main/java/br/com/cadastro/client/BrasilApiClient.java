package main.java.br.com.cadastro.client;

import main.java.br.com.cadastro.model.Empresa;
import com.google.gson.Gson;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class BrasilApiClient {

    public Empresa buscarEmpresa(String cnpj) throws Exception {

        HttpClient client = HttpClient.newHttpClient();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI("https://brasilapi.com.br/api/cnpj/v1/" + cnpj))
                .GET()
                .build();

        HttpResponse<String> response = client.send(
                request,
                HttpResponse.BodyHandlers.ofString()
        );

        if (response.statusCode() == 200) {

            Gson gson = new Gson();
            return gson.fromJson(response.body(), Empresa.class);

        } else {
            throw new RuntimeException("Erro ao consultar API: " + response.statusCode());
        }
    }
}