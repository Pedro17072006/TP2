package main.java.br.com.cadastro.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class Empresa {

    private String cnpj;

    @SerializedName("razao_social")
    private String razaoSocial;

    @SerializedName("nome_fantasia")
    private String nomeFantasia;

    private String logradouro;

    private List<Socio> qsa;

    public String getCnpj() {
        return cnpj;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public List<Socio> getQsa() {
        return qsa;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public void setQsa(List<Socio> qsa) {
        this.qsa = qsa;
    }
}