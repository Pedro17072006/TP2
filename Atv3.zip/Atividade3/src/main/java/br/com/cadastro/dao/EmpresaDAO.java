package main.java.br.com.cadastro.dao;

import main.java.br.com.cadastro.model.Empresa;
import main.java.br.com.cadastro.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class EmpresaDAO {

    public void salvar(Empresa empresa) {

        String sql = """
                INSERT INTO empresas(cnpj, razao_social, nome_fantasia, logradouro)
                VALUES (?, ?, ?, ?)
                """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, empresa.getCnpj());
            stmt.setString(2, empresa.getRazaoSocial());
            stmt.setString(3, empresa.getNomeFantasia());
            stmt.setString(4, empresa.getLogradouro());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}