package main.java.br.com.cadastro;

import main.java.br.com.cadastro.client.BrasilApiClient;
import main.java.br.com.cadastro.dao.EmpresaDAO;
import main.java.br.com.cadastro.dao.SocioDAO;
import main.java.br.com.cadastro.model.Empresa;
import main.java.br.com.cadastro.model.Socio;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        try (Scanner scanner = new Scanner(System.in)) {

            System.out.println("Digite o CNPJ:");
            String cnpj = scanner.nextLine();

            cnpj = cnpj.replaceAll("[^0-9]", "");

            BrasilApiClient client = new BrasilApiClient();
            Empresa empresa = client.buscarEmpresa(cnpj);

            if (empresa == null) {
                System.out.println("Empresa não encontrada.");
                return;
            }

            EmpresaDAO empresaDAO = new EmpresaDAO();
            empresaDAO.salvar(empresa);

            SocioDAO socioDAO = new SocioDAO();

            if (empresa.getQsa() != null && !empresa.getQsa().isEmpty()) {
                for (Socio socio : empresa.getQsa()) {
                    socioDAO.salvar(socio, empresa.getCnpj());
                }
            }

            System.out.println("Empresa cadastrada com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}