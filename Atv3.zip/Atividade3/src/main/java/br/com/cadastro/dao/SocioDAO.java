package main.java.br.com.cadastro.dao;

import main.java.br.com.cadastro.model.Socio;
import main.java.br.com.cadastro.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class SocioDAO {

    public void salvar(Socio socio, String cnpjEmpresa) {

        String sql = """
                INSERT INTO socios(cnpj_empresa, nome_socio, cnpj_cpf_socio, qualificacao_socio)
                VALUES (?, ?, ?, ?)
                """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cnpjEmpresa);
            stmt.setString(2, socio.getNomeSocio());
            stmt.setString(3, socio.getCnpjCpfSocio());
            stmt.setString(4, socio.getQualificacaoSocio());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}