CREATE TABLE empresas (
                          cnpj VARCHAR(14) PRIMARY KEY,
                          razao_social TEXT,
                          nome_fantasia TEXT,
                          logradouro TEXT
);

CREATE TABLE socios (
                        id SERIAL PRIMARY KEY,
                        cnpj_empresa VARCHAR(14),
                        nome_socio TEXT,
                        cnpj_cpf_socio TEXT,
                        qualificacao_socio TEXT,

                        FOREIGN KEY (cnpj_empresa)
                            REFERENCES empresas(cnpj)
);
